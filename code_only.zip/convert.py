# convert.py
import os

model_path = os.path.abspath("NLP/models/whisper")
output_path = os.path.abspath("NLP/models/whisper_ct2")

print(f"[CONVERT] ctranslate2: 4.7.1")
print(f"[CONVERT] Input:  {model_path}")
print(f"[CONVERT] Output: {output_path}")
print("[CONVERT] Converting using TransformersConverter...")
print("[CONVERT] Please wait (2-5 minutes)...")

try:
    from ctranslate2.converters import TransformersConverter

    converter = TransformersConverter(model_path)

    converter.convert(
        output_path,
        quantization="int8",
        force=True
    )

    print("\n[CONVERT] ✅ Conversion successful!")
    print("[CONVERT] Output files:")
    for f in os.listdir(output_path):
        size = os.path.getsize(os.path.join(output_path, f))
        print(f"  - {f} ({size // 1024} KB)")

    print("\n[CONVERT] Now run:")
    print("  rd /s /q NLP\\models\\whisper")
    print("  rename NLP\\models\\whisper_ct2 whisper")

except Exception as e:
    print(f"\n[CONVERT] ❌ Error: {e}")
    import traceback
    traceback.print_exc()